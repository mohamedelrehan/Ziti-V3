# OpenZiti V3 test04 - FQDN Native Router Bootstrap

This version fixes the TLS SAN issue by using the controller FQDN for router enrollment:

```text
https://<controller-fqdn>:1280
```

It keeps the native OpenZiti router bootstrap method:

```text
/opt/openziti/etc/router/bootstrap.bash
```

Upload this file to GitHub root before deployment:

```text
azure-bootstrap-ziti-router-v3.sh
```

Required repo files:

```text
azure-bootstrap-ziti-v3.sh
azure-bootstrap-ziti-router-v3.sh
install-openziti-v2-controller-zac.sh
install-nginx-letsencrypt-zac-fix.sh
```

Validate on controller:

```bash
ziti edge login https://localhost:1280 -u admin
ziti edge list edge-routers
ziti fabric list routers
```

Validate on routers:

```bash
sudo /opt/ziti-v3-router/check-router.sh
sudo systemctl status ziti-router --no-pager -l
```
