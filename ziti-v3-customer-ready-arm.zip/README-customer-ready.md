# OpenZiti V3 Customer-Ready Azure ARM Package

## Important

Upload this file to the root of your GitHub repo before deployment:

```text
azure-bootstrap-ziti-v3.sh
```

Repo root must contain:

```text
azure-bootstrap-ziti-v3.sh
install-openziti-v2-controller-zac.sh
install-nginx-letsencrypt-zac-fix.sh
```

Verify:

```bash
curl -I https://raw.githubusercontent.com/mohamedelrehan/Ziti-V3/main/azure-bootstrap-ziti-v3.sh
curl -s https://raw.githubusercontent.com/mohamedelrehan/Ziti-V3/main/azure-bootstrap-ziti-v3.sh | bash -n
```

## Security default

The template opens:

```text
22/tcp
80/tcp
443/tcp
```

It does not expose 1280 by default. Browser access is through:

```text
https://<azure-fqdn>/zac/
```

NGINX proxies locally to:

```text
https://127.0.0.1:1280
```

## Deploy

Deploy `mainTemplate.json` into an existing resource group.

## Health checks

SSH to the VM and run:

```bash
sudo cat /opt/ziti-v3/bootstrap-status.txt
sudo /opt/ziti-v3/check-ziti-v3.sh
sudo tail -100 /var/log/ziti-v3-bootstrap.log
```

## Cert renewal

The bootstrap runs:

```bash
systemctl enable certbot.timer
systemctl start certbot.timer
certbot renew --dry-run
```

when certificate setup succeeds.

## If cert is pending

Run later:

```bash
sudo /opt/ziti-v3/run-nginx-letsencrypt-later.sh
```
